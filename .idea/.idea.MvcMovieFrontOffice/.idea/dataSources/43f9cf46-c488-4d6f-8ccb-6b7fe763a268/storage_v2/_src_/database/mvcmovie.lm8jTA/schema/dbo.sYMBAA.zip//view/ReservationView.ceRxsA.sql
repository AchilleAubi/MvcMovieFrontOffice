CREATE VIEW [dbo].[ReservationView] AS
SELECT 
    r.id as ReservationId,
    r.startDate as StartDate,
    r.endDate as EndDate,
    r.status as Status,
    r.totalPrice,
    r.amount as AmountPayed,
    v.id as VehicleId,
    v.model as Model,
    v.make as Make,
    v.availability as Availability,
    u.Id as UserId,
    u.FullName,
    u.Email
FROM reservations as r INNER JOIN vehicles as v ON r.vehicleId = v.id INNER JOIN AspNetUsers as u ON r.userId = u.Id;  
go


CREATE VIEW [dbo].[VehicleView] AS
SELECT 
    V.id AS VehicleId,
    V.model,
    V.make,
    V.year,
    V.availability,
    V.price,
    V.createdAt AS CreatedAt,
    V.updatedAt AS UpdatedAt,
    VT.id AS VehicleTypeId,
    VT.name AS VehicleType,
    V.image AS VehicleImage
FROM [dbo].[vehicles] AS V
INNER JOIN [dbo].[vehicleTypes] AS VT 
    ON VT.id = V.typeId
go

